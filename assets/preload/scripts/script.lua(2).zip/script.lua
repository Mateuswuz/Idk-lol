function onCreate() 
makeLuaText('watermark',"Ported By Sinix Go ", 0, 2, 688); -- You can edit the created by Prisma Text just dont change anything else
    setTextSize('watermark', 20);
    addLuaText('watermark');
end